import { useState, useEffect } from "react";
import {
  HashRouter,
  Routes,
  Route,
  useNavigate,
} from "react-router-dom";
import { WelcomePage } from "./components/WelcomePage";
import { HomePage } from "./components/HomePage";
import { FacilityDetailPage } from "./components/FacilityDetailPage";
import { LoginPage } from "./components/LoginPage";
import { Toaster } from "./components/ui/sonner";
import { toast } from "sonner";
import copierImage from "figma:asset/ff0a0d71f262ec9cc6c921ea09cde1aa1953ca1d.png";
import loungeImage from "figma:asset/083e4201308784dcbbd830b089fc0dae10e6456a.png";
import libraryImage from "figma:asset/7fa34b752ab7f2bfe93d3a0bbc34f15f47024fe8.png";

export interface Facility {
  id: number;
  name: string;
  category:
    | "cafe"
    | "restaurant"
    | "library"
    | "atm"
    | "convenience"
    | "medical"
    | "gym"
    | "lounge"
    | "transport";
  building: string;
  floor: string;
  hours: string;
  description?: string;
  contact?: string;
  image?: string;
  latitude: number;
  longitude: number;
  isFavorite?: boolean;
}

export interface FloorInfo {
  floor: string;
  facilities: Facility[];
}

export interface GroupedFacility {
  building: string;
  category:
    | "cafe"
    | "restaurant"
    | "library"
    | "atm"
    | "convenience"
    | "medical"
    | "gym"
    | "lounge"
    | "transport";
  latitude: number;
  longitude: number;
  floors: FloorInfo[];
  isFavorite: boolean;
}

export interface User {
  id: string;
  email: string;
  password: string;
  name: string;
}

// 백석대학교 편의시설 초기 데이터
const initialFacilities: Facility[] = [
  // 본부동
  {
    id: 1,
    name: "매점",
    category: "convenience",
    building: "본부동",
    floor: "6층",
    hours: "평일 09:00-18:00",
    description:
      "간식류, 음료, 문구류 등을 구매할 수 있습니다. 교직원 및 학생 모두 편리하게 이용할 수 있는 시설입니다. 비교적 간단한 생활필수품도 함께 구비되어 있습니다.",
    contact: "041-620-9509",
    latitude: 36.7672,
    longitude: 127.0744,
    isFavorite: false,
  },
  {
    id: 2,
    name: "가스펠 하우스",
    category: "cafe",
    building: "본부동",
    floor: "지하 1층",
    hours: "평일 08:00-19:00",
    description:
      "학생들에게 식사와 차, 음료 등을 저렴한 가격으로 공급하고 있습니다.",
    contact: "041-550-0858",
    latitude: 36.767,
    longitude: 127.0742,
    isFavorite: false,
  },
  {
    id: 3,
    name: "복사기",
    category: "convenience",
    building: "본부동",
    floor: "6층 로비",
    hours: "평일 09:00-18:00",
    description:
      "학생들의 문서 출력과 복사 작업을 빠르게 처리할 수 있습니다. 카드 결제 기반으로 간편하게 사용됩니다. 수업 전후로 이용이 많은 편입니다.",
    contact: "041-550-0722",
    image: copierImage,
    latitude: 36.7672,
    longitude: 127.0745,
    isFavorite: false,
  },
  {
    id: 4,
    name: "복사기",
    category: "convenience",
    building: "본부동",
    floor: "8층 로비",
    hours: "평일 09:00-18:00",
    description:
      "학생들의 문서 출력과 복사 작업을 빠르게 처리할 수 있습니다. 카드 결제 기반으로 간편하게 사용됩니다. 수업 전후로 이용이 많은 편입니다.",
    contact: "041-550-0722",
    image: copierImage,
    latitude: 36.7673,
    longitude: 127.0745,
    isFavorite: false,
  },
  {
    id: 5,
    name: "라운지",
    category: "lounge",
    building: "본부동",
    floor: "3층",
    hours: "24시간",
    description:
      "학생들이 쉬거나 개인 공부를 할 수 있는 개방형 공간입니다. 좌석과 테이블이 잘 배치되어 이용이 편합니다. 자연광이 들어오는 편안한 분위기로 구성됩니다.",
    image: loungeImage,
    latitude: 36.7671,
    longitude: 127.0743,
    isFavorite: false,
  },
  {
    id: 6,
    name: "라운지",
    category: "lounge",
    building: "본부동",
    floor: "4층",
    hours: "24시간",
    description:
      "학생들이 쉬거나 개인 공부를 할 수 있는 개방형 공간입니다. 좌석과 테이블이 잘 배치되어 이용이 편합니다. 자연광이 들어오는 편안한 분위기로 구성됩니다.",
    image: loungeImage,
    latitude: 36.7671,
    longitude: 127.0744,
    isFavorite: false,
  },
  {
    id: 7,
    name: "라운지",
    category: "lounge",
    building: "본부동",
    floor: "5층",
    hours: "24시간",
    description:
      "학생들이 쉬거나 개인 공부를 할 수 있는 개방형 공간입니다. 좌석과 테이블이 잘 배치되어 이용이 편합니다. 자연광이 들어오는 편안한 분위기로 구성됩니다.",
    image: loungeImage,
    latitude: 36.7672,
    longitude: 127.0743,
    isFavorite: false,
  },
  {
    id: 8,
    name: "라운지",
    category: "lounge",
    building: "본부동",
    floor: "6층",
    hours: "24시간",
    description:
      "학생들이 쉬거나 개인 공부를 할 수 있는 개방형 공간입니다. 좌석과 테이블이 잘 배치되어 이용이 편합니다. 자연광이 들어오는 편안한 분위기로 구성됩니다.",
    image: loungeImage,
    latitude: 36.7672,
    longitude: 127.0744,
    isFavorite: false,
  },
  {
    id: 9,
    name: "라운지",
    category: "lounge",
    building: "본부동",
    floor: "7층",
    hours: "24시간",
    description:
      "학생들이 쉬거나 개인 공부를 할 수 있는 개방형 공간입니다. 좌석과 테이블이 잘 배치되어 이용이 편합니다. 자연광이 들어오는 편안한 분위기로 구성됩니다.",
    image: loungeImage,
    latitude: 36.7673,
    longitude: 127.0743,
    isFavorite: false,
  },
  {
    id: 10,
    name: "라운지",
    category: "lounge",
    building: "본부동",
    floor: "8층",
    hours: "24시간",
    description:
      "학생들이 쉬거나 개인 공부를 할 수 있는 개방형 공간입니다. 좌석과 테이블이 잘 배치되어 이용이 편합니다. 자연광이 들어오는 편안한 분위기로 구성됩니다.",
    image: loungeImage,
    latitude: 36.7673,
    longitude: 127.0744,
    isFavorite: false,
  },
  {
    id: 11,
    name: "라운지",
    category: "lounge",
    building: "본부동",
    floor: "9층",
    hours: "24시간",
    description:
      "학생들이 쉬거나 개인 공부를 할 수 있는 개방형 공간입니다. 좌석과 테이블이 잘 배치되어 이용이 편합니다. 자연광이 들어오는 편안한 분위기로 구성됩니다.",
    image: loungeImage,
    latitude: 36.7674,
    longitude: 127.0743,
    isFavorite: false,
  },
  // 진리관
  {
    id: 12,
    name: "우체국",
    category: "convenience",
    building: "진리관",
    floor: "1층",
    hours: "평일 09:00-17:00",
    description:
      "우편 발송, 택배 접수, 금융 관련 서비스를 제공합니다. 학생과 교직원이 자주 이용하는 기관입니다. 학교 내부에서 우편 업무를 처리할 수 있어 편리합니다.",
    contact: "041-550-0730",
    latitude: 36.7668,
    longitude: 127.0748,
    isFavorite: false,
  },
  {
    id: 13,
    name: "서점",
    category: "convenience",
    building: "진리관",
    floor: "1층",
    hours: "평일 09:00-18:00",
    description:
      "교재, 문구류, 학습용 도서를 구매할 수 있습니다. 학기 초 교재 구매 수요가 많습니다. 다양한 참고서와 잡지도 함께 비치되어 있습니다.",
    contact: "041-550-9198",
    latitude: 36.7669,
    longitude: 127.0748,
    isFavorite: false,
  },
  {
    id: 14,
    name: "복사기",
    category: "convenience",
    building: "진리관",
    floor: "1층",
    hours: "평일 09:00-18:00",
    description:
      "학생들의 기본적인 출력 및 복사 작업을 지원합니다. 간단한 문서 작업을 빠르게 처리할 수 있습니다. 시험 기간에 이용량이 증가합니다.",
    contact: "041-550-0722",
    latitude: 36.7668,
    longitude: 127.0749,
    isFavorite: false,
  },
  {
    id: 15,
    name: "복사기",
    category: "convenience",
    building: "진리관",
    floor: "3층 별관",
    hours: "평일 09:00-18:00",
    description:
      "학생들의 기본적인 출력 및 복사 작업을 지원합니다. 간단한 문서 작업을 빠르게 처리할 수 있습니다. 시험 기간에 이용량이 증가합니다.",
    contact: "041-550-0722",
    latitude: 36.7669,
    longitude: 127.0749,
    isFavorite: false,
  },
  {
    id: 16,
    name: "보건실",
    category: "medical",
    building: "진리관",
    floor: "1층",
    hours: "평일 09:00-18:00",
    description:
      "학생들의 기본적인 응급 처치와 상담을 지원합니다. 상비약을 제공하며 가벼운 부상에 대한 진료가 가능합니다. 건강 관련 문의도 친절히 안내됩니다.",
    latitude: 36.7668,
    longitude: 127.0747,
    isFavorite: false,
  },
  {
    id: 17,
    name: "여학생회복실",
    category: "lounge",
    building: "진리관",
    floor: "1층",
    hours: "평일 09:00-18:00",
    description:
      "여학생들을 위한 전용 휴식 공간입니다. 편안하게 쉴 수 있는 환경이 제공됩니다. 필요 시 간단한 준비물을 보관하거나 사용하기도 합니다.",
    latitude: 36.7668,
    longitude: 127.0746,
    isFavorite: false,
  },
  // 학생복지관
  {
    id: 18,
    name: "식당",
    category: "restaurant",
    building: "학생복지관",
    floor: "지하 1층",
    hours: "평일 11:30-13:30, 17:30-19:00",
    description:
      "학생들에게 합리적인 가격의 식사를 제공합니다. 다양한 메뉴가 준비되어 많은 학생이 이용합니다. 점심시간에는 붐비는 편입니다.",
    contact: "041-550-9576",
    latitude: 36.7665,
    longitude: 127.075,
    isFavorite: false,
  },
  {
    id: 19,
    name: "사진관",
    category: "convenience",
    building: "학생복지관",
    floor: "2층",
    hours: "평일 09:00-18:00",
    description:
      "증명사진, 여권사진 등 다양한 사진 촬영 서비스를 제공합니다. 빠른 편집과 출력으로 학생들의 서류 준비에 도움됩니다. 비교적 합리적인 가격으로 운영됩니다.",
    contact: "041-550-0471",
    latitude: 36.7665,
    longitude: 127.0751,
    isFavorite: false,
  },
  {
    id: 20,
    name: "복사점",
    category: "convenience",
    building: "학생복지관",
    floor: "지하 1층",
    hours: "평일 09:00-18:00",
    description:
      "출력, 제본, 양면 복사 등 다양한 문서 작업 서비스를 제공합니다. 과제 제출 시즌에 특히 이용이 많습니다. 컬러 출력도 지원됩니다.",
    contact: "041-561-0722",
    latitude: 36.7666,
    longitude: 127.075,
    isFavorite: false,
  },
  {
    id: 21,
    name: "복사기",
    category: "convenience",
    building: "학생복지관",
    floor: "2층",
    hours: "평일 09:00-18:00",
    description:
      "학생들이 간단하게 출력이나 복사를 이용할 수 있습니다. 대기 시간 없이 바로 사용할 수 있어 편리합니다. 수업 준비에 실용적으로 활용됩니다.",
    latitude: 36.7665,
    longitude: 127.0752,
    isFavorite: false,
  },
  {
    id: 22,
    name: "탁구장",
    category: "gym",
    building: "학생복지관",
    floor: "지하 1층",
    hours: "평일 09:00-21:00",
    description:
      "학생들의 여가와 운동을 위한 공간으로 운영됩니다. 동아리 활동이나 개인 이용 모두 가능합니다. 스트레스를 해소하기 좋은 시설입니다.",
    latitude: 36.7666,
    longitude: 127.0751,
    isFavorite: false,
  },
  // 목양관
  {
    id: 23,
    name: "복사점",
    category: "convenience",
    building: "목양관",
    floor: "1층",
    hours: "평일 09:00-18:00",
    description:
      "출력, 제본, 복사 등의 문서 작업 서비스를 제공합니다. 과제 제출이나 보고서 출력에 자주 이용됩니다. 비교적 빠른 작업 속도와 편리한 결제가 지원됩니다.",
    contact: "041-561-0722",
    latitude: 36.7677,
    longitude: 127.074,
    isFavorite: false,
  },
  {
    id: 24,
    name: "휴게실",
    category: "lounge",
    building: "목양관",
    floor: "3층",
    hours: "24시간",
    description:
      "학생들이 수업 사이에 휴식할 수 있는 공간입니다. 소파와 테이블이 마련되어 있으며 간단한 공부나 대화를 하기에도 좋습니다. 비교적 조용한 분위기로 구성됩니다.",
    latitude: 36.7677,
    longitude: 127.0741,
    isFavorite: false,
  },
  {
    id: 25,
    name: "휴게실",
    category: "lounge",
    building: "목양관",
    floor: "4층",
    hours: "24시간",
    description:
      "학생들이 수업 사이에 휴식할 수 있는 공간입니다. 소파와 테이블이 마련되어 있으며 간단한 공부나 대화를 하기에도 좋습니다. 비교적 조용한 분위기로 구성됩니다.",
    latitude: 36.7677,
    longitude: 127.0742,
    isFavorite: false,
  },
  {
    id: 26,
    name: "휴게실",
    category: "lounge",
    building: "목양관",
    floor: "5층",
    hours: "24시간",
    description:
      "학생들이 수업 사이에 휴식할 수 있는 공간입니다. 소파와 테이블이 마련되어 있으며 간단한 공부나 대화를 하기에도 좋습니다. 비교적 조용한 분위기로 구성됩니다.",
    latitude: 36.7677,
    longitude: 127.0743,
    isFavorite: false,
  },
  // 교수회관
  {
    id: 27,
    name: "식당",
    category: "restaurant",
    building: "교수회관",
    floor: "1층",
    hours: "평일 11:30-13:30, 17:30-19:00",
    description:
      "학교 구성원들에게 균형 잡힌 식사를 제공합니다. 다양한 한식 메뉴가 제공되며 가격이 합리적으로 운영됩니다. 점심시간에는 많은 학생들이 좋아하는 인기 공간입니다.",
    contact: "041-620-9578",
    latitude: 36.768,
    longitude: 127.0735,
    isFavorite: false,
  },
  {
    id: 28,
    name: "교수식당",
    category: "restaurant",
    building: "교수회관",
    floor: "2층",
    hours: "평일 11:30-13:30",
    description:
      "조용한 분위기에서 식사를 제공하며 품질 높은 메뉴가 준비됩니다. 점심 이후 시간에는 학생들도 이용할 수 있도록 운영됩니다. 비교적 여유로운 환경에서 식사가 가능합니다.",
    contact: "041-620-9578",
    latitude: 36.768,
    longitude: 127.0736,
    isFavorite: false,
  },
  {
    id: 29,
    name: "매점",
    category: "convenience",
    building: "교수회관",
    floor: "1층",
    hours: "평일 09:00-18:00",
    description:
      "학용품, 간식류, 음료 등을 판매합니다. 학생 편의를 위해 다양한 생활용품을 빠르게 구매할 수 있습니다. 이동 중 가볍게 이용하기 좋은 공간입니다.",
    latitude: 36.7681,
    longitude: 127.0735,
    isFavorite: false,
  },
  // 예술동
  {
    id: 30,
    name: "매점",
    category: "convenience",
    building: "예술동",
    floor: "5층",
    hours: "평일 09:00-18:00",
    description:
      "예술 계열 학생들을 위한 간식류와 학용품을 제공합니다. 수업 중간에 편하게 이용할 수 있습니다. 접근성이 좋아 이용률이 높은 편입니다.",
    contact: "041-620-9676",
    latitude: 36.7685,
    longitude: 127.0738,
    isFavorite: false,
  },
  {
    id: 31,
    name: "복사기",
    category: "convenience",
    building: "예술동",
    floor: "1층 로비",
    hours: "평일 09:00-18:00",
    description:
      "디자인 출력이나 일반 문서 작업에 사용됩니다. 학생들이 과제 제출 전 많이 이용합니다. 언제든 간단히 출력할 수 있는 편의성을 제공합니다.",
    contact: "041-561-0722",
    latitude: 36.7685,
    longitude: 127.0739,
    isFavorite: false,
  },
  {
    id: 32,
    name: "복사기",
    category: "convenience",
    building: "예술동",
    floor: "7층",
    hours: "평일 09:00-18:00",
    description:
      "디자인 출력이나 일반 문서 작업에 사용됩니다. 학생들이 과제 제출 전 많이 이용합니다. 언제든 간단히 출력할 수 있는 편의성을 제공합니다.",
    contact: "041-561-0722",
    latitude: 36.7686,
    longitude: 127.0738,
    isFavorite: false,
  },
  // 인성관
  {
    id: 33,
    name: "증명서 발급기",
    category: "convenience",
    building: "인성관",
    floor: "1층 로비",
    hours: "24시간",
    description:
      "각종 학교 증명서를 자동으로 발급합니다. 학생증만 있으면 빠르게 발급할 수 있어 편리합니다. 병무서·공공기관 제출 서류 준비에도 활용됩니다.",
    contact: "041-550-0780",
    latitude: 36.767,
    longitude: 127.0755,
    isFavorite: false,
  },
  // 백석생활관
  {
    id: 34,
    name: "식당",
    category: "restaurant",
    building: "백석생활관",
    floor: "1층",
    hours: "평일 07:30-09:00, 11:30-13:00, 17:30-19:00",
    description:
      "학생들에게 영양을 고려한 식사를 제공합니다. 메뉴가 주기적으로 변경되어 선택의 폭이 넓습니다. 생활관 학생들의 이용이 많아 운영 효율이 높습니다.",
    contact: "010-8805-1215",
    latitude: 36.769,
    longitude: 127.073,
    isFavorite: false,
  },
  // 통학버스
  {
    id: 35,
    name: "신정관광 / 블루관광 (통학버스)",
    category: "transport",
    building: "통학버스승차장",
    floor: "통학버스승차장",
    hours: "평일 07:00-22:00",
    description:
      "학생들의 통학을 지원하는 버스 운행 서비스를 제공합니다. 시간표에 따라 정해진 노선으로 운행됩니다. 통학 거리 부담을 줄여주는 편리한 교통 수단입니다.",
    contact: "041-567-3001",
    latitude: 36.7675,
    longitude: 127.0745,
    isFavorite: false,
  },
  // 도서관
  {
    id: 36,
    name: "도서관",
    category: "library",
    building: "본부동",
    floor: "1층",
    hours: "평일 09:00-18:00",
    description:
      "학생들이 인터넷 검색이나 자료 탐색을 할 수 있는 곳입니다. 연구 및 과제 준비에 필요한 자료 접근이 용이합니다. 비교적 조용한 환경을 제공합니다.",
    image: libraryImage,
    latitude: 36.767,
    longitude: 127.0745,
    isFavorite: false,
  },
  {
    id: 37,
    name: "본부동 5층 (맥실습실)",
    category: "library",
    building: "본부동",
    floor: "5층",
    hours: "평일 09:00-18:00",
    description:
      "Mac 기반 작업 환경이 구축되어 디자인 및 영상 관련 작업에 활용됩니다. 전문 프로그램 실습이 가능하도록 장비가 구성됩니다. 관련 학과 학생의 실습 비중이 높습니다.",
    contact: "041-620-9714",
    latitude: 36.7671,
    longitude: 127.0745,
    isFavorite: false,
  },
  {
    id: 38,
    name: "목양관 5층 (개방전산실)",
    category: "library",
    building: "목양관",
    floor: "5층",
    hours: "평일 09:00-18:00",
    description:
      "학생들이 자유롭게 컴퓨터를 사용할 수 있는 공간입니다. 워드 작업, 인터넷 자료 검색 등 학업용으로 활용됩니다. 비교적 안정적인 장비 환경을 제공합니다.",
    latitude: 36.7677,
    longitude: 127.0744,
    isFavorite: false,
  },
  {
    id: 39,
    name: "백석학술정보관 (디지털 정보실)",
    category: "library",
    building: "백석학술정보관",
    floor: "2층",
    hours: "평일 09:00-21:00 (학기 중)",
    description:
      "전자자료 열람과 인터넷 검색이 가능한 학습 공간입니다. 컴퓨터와 관련 장비가 안정적으로 구성되어 있습니다. 조용한 분위기에서 정보 탐색이 가능합니다.",
    contact: "041-620-9613",
    latitude: 36.7675,
    longitude: 127.0752,
    isFavorite: false,
  },
];

const FAVORITES_STORAGE_KEY = "cc_favorites";
const USERS_STORAGE_KEY = "cc_users";
const CURRENT_USER_KEY = "cc_current_user";

export default function App() {
  const [selectedCategory, setSelectedCategory] =
    useState<string>("all");
  const [facilities, setFacilities] = useState<Facility[]>(
    initialFacilities,
  );
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [currentUser, setCurrentUser] = useState<User | null>(
    null,
  );

  // 로그인된 사용자 불러오기
  useEffect(() => {
    const loadCurrentUser = () => {
      try {
        const stored = localStorage.getItem(CURRENT_USER_KEY);
        if (stored) {
          const user: User = JSON.parse(stored);
          setCurrentUser(user);
        }
      } catch (error) {
        console.error("Failed to load current user:", error);
      }
    };

    loadCurrentUser();
  }, []);

  // 사용자별 즐겨찾기 불러오기
  useEffect(() => {
    const loadFavorites = () => {
      try {
        if (!currentUser) {
          // 로그인하지 않은 경우 초기화
          setFacilities(initialFacilities);
          return;
        }

        // 사용자별 즐겨찾기 키
        const userFavoritesKey = `${FAVORITES_STORAGE_KEY}_${currentUser.id}`;
        const stored = localStorage.getItem(userFavoritesKey);

        if (stored) {
          const favoriteIds: number[] = JSON.parse(stored);
          setFacilities((prev) =>
            prev.map((facility) => ({
              ...facility,
              isFavorite: favoriteIds.includes(facility.id),
            })),
          );
        } else {
          setFacilities(initialFacilities);
        }
      } catch (error) {
        console.error("Failed to load favorites:", error);
      }
    };

    loadFavorites();
  }, [currentUser]);

  // 로그인 핸들러
  const handleLogin = (email: string, password: string) => {
    try {
      const stored = localStorage.getItem(USERS_STORAGE_KEY);
      const users: User[] = stored ? JSON.parse(stored) : [];

      const user = users.find(
        (u) => u.email === email && u.password === password,
      );

      if (user) {
        setCurrentUser(user);
        localStorage.setItem(
          CURRENT_USER_KEY,
          JSON.stringify(user),
        );
        toast.success(`${user.name}님, 환영합니다!`);

        // 로그인 후 홈으로 이동
        window.location.hash = "/map";
      } else {
        toast.error(
          "이메일 또는 비밀번호가 올바르지 않습니다.",
        );
      }
    } catch (error) {
      console.error("Login failed:", error);
      toast.error("로그인에 실패했습니다.");
    }
  };

  // 회원가입 핸들러
  const handleSignup = (
    email: string,
    password: string,
    name: string,
  ) => {
    try {
      const stored = localStorage.getItem(USERS_STORAGE_KEY);
      const users: User[] = stored ? JSON.parse(stored) : [];

      // 이메일 중복 확인
      if (users.find((u) => u.email === email)) {
        toast.error("이미 등록된 이메일입니다.");
        return;
      }

      // 새 사용자 생성
      const newUser: User = {
        id: Date.now().toString(),
        email,
        password,
        name,
      };

      users.push(newUser);
      localStorage.setItem(
        USERS_STORAGE_KEY,
        JSON.stringify(users),
      );

      toast.success(
        "회원가입이 완료되었습니다! 로그인해주세요.",
      );
    } catch (error) {
      console.error("Signup failed:", error);
      toast.error("회원가입에 실패했습니다.");
    }
  };

  // 로그아웃 핸들러
  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem(CURRENT_USER_KEY);
    setFacilities(initialFacilities);
    toast.success("로그아웃되었습니다.");
  };

  // 즐겨찾기 토글 함수
  const toggleFavorite = (facilityId: number) => {
    setFacilities((prev) => {
      const updated = prev.map((facility) =>
        facility.id === facilityId
          ? { ...facility, isFavorite: !facility.isFavorite }
          : facility,
      );

      // localStorage에 저장
      if (currentUser) {
        const userFavoritesKey = `${FAVORITES_STORAGE_KEY}_${currentUser.id}`;
        const favoriteIds = updated
          .filter((f) => f.isFavorite)
          .map((f) => f.id);

        try {
          localStorage.setItem(
            userFavoritesKey,
            JSON.stringify(favoriteIds),
          );

          // 토스트 메시지
          const facility = updated.find(
            (f) => f.id === facilityId,
          );
          if (facility) {
            if (facility.isFavorite) {
              toast.success("즐겨찾기에 추가되었습니다");
            } else {
              toast.success("즐겨찾기에서 제거되었습니다");
            }
          }
        } catch (error) {
          console.error("Failed to save favorites:", error);
          toast.error("즐겨찾기 저장에 실패했습니다");
        }
      }

      return updated;
    });
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<WelcomePage />} />
        <Route
          path="/map"
          element={
            <HomePage
              facilities={facilities}
              onToggleFavorite={toggleFavorite}
              currentUser={currentUser}
              onLogout={handleLogout}
            />
          }
        />
        <Route
          path="/facility/:id"
          element={
            <FacilityDetailPage facilities={facilities} />
          }
        />
        <Route
          path="/login"
          element={
            <LoginPage
              onLogin={handleLogin}
              onSignup={handleSignup}
            />
          }
        />
      </Routes>

      {/* Toast Notifications */}
      <Toaster position="top-center" />
    </HashRouter>
  );
}