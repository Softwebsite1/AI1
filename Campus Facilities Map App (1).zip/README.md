
  # Campus Facilities Map App

  This is a code bundle for Campus Facilities Map App. The original project is available at https://www.figma.com/design/DRgq1DRHzTsQe5j7ouD1gF/Campus-Facilities-Map-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  